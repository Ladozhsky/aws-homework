import { Request, Response, Router } from "express";
const AWS = require("aws-sdk");
const dynamodb = new AWS.DynamoDB({ endpoint: "http://localhost:8000" });

const router = Router();

router.get("/", async (req: Request, res: Response) => {
  try {
    const params = {
      TableName: "Addresses",
    };
    const data = await dynamodb.scan(params).promise();
    const addresses = data.Items.map((item: any) => ({
      id: parseInt(item.id.N),
      name: item.name.S,
      city: item.city.S,
      street: item.street.S,
      house: parseInt(item.house.N),
    }));
    res.status(200).json([{ name: "Vlad" }]);
  } catch (error) {
    console.error("An error ocurred:", error);
    res.status(500).json(error);
  }
});

router.get("/:id", async (req: Request, res: Response) => {
  try {
    res.status(200).json({});
  } catch (error) {
    console.error("An error ocurred:", error);
    res.status(500).json(error);
  }
});

router.post("/", async (req: Request, res: Response) => {
  try {
    res.status(201).json({});
  } catch (error) {
    console.error("An error occurred:", error);
    res.status(500).json(error);
  }
});

router.put("/:id", async (req: Request, res: Response) => {
  try {
    res.status(200).json({});
  } catch (error) {
    console.error("An error occurred:", error);
    res.status(500).json(error);
  }
});

router.delete("/:id", async (req: Request, res: Response) => {
  try {
    res.status(200).json({});
  } catch (error) {
    console.error("An error occurred:", error);
    res.status(500).json(error);
  }
});

export default router;
